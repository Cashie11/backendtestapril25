<!DOCTYPE html>
<html>
<head>
    <title>Weekly Expense Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .summary {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .category {
            font-weight: bold;
        }
        .total {
            font-weight: bold;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <h1>Weekly Expense Report</h1>
    
    <div class="summary">
        <p><strong>Period:</strong> {{ $reportData['period']['start'] }} to {{ $reportData['period']['end'] }}</p>
        <p><strong>Total Expenses:</strong> {{ $reportData['total_expenses'] }}</p>
        <p><strong>Total Amount:</strong> ${{ number_format($reportData['total_amount'], 2) }}</p>
    </div>
    
    <h2>Category Summary</h2>
    <table>
        <thead>
            <tr>
                <th>Category</th>
                <th>Count</th>
                <th>Total Amount</th>
            </tr>
        </thead>
        <tbody>
            @foreach($reportData['category_summary'] as $category => $data)
            <tr>
                <td class="category">{{ $category }}</td>
                <td>{{ $data['count'] }}</td>
                <td>${{ number_format($data['total'], 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <h2>Expense Details</h2>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Employee</th>
                <th>Title</th>
                <th>Category</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            @foreach($reportData['expenses'] as $expense)
            <tr>
                <td>{{ \Carbon\Carbon::parse($expense->created_at)->format('Y-m-d') }}</td>
                <td>{{ $expense->user->name }}</td>
                <td>{{ $expense->title }}</td>
                <td>{{ $expense->category }}</td>
                <td>${{ number_format($expense->amount, 2) }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <p>This is an automated report. Please do not reply to this email.</p>
</body>
</html>
