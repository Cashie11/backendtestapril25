<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Expense Management Routes
Route::middleware(['auth:sanctum', 'role:Admin,Manager,Employee'])
    ->get('/expenses', [ExpenseController::class, 'index']);

Route::middleware(['auth:sanctum', 'role:Admin,Manager,Employee'])
    ->post('/expenses', [ExpenseController::class, 'store']);

Route::middleware(['auth:sanctum', 'role:Admin,Manager', 'company.access'])
    ->put('/expenses/{expense}', [ExpenseController::class, 'update']);

Route::middleware(['auth:sanctum', 'role:Admin', 'company.access'])
    ->delete('/expenses/{expense}', [ExpenseController::class, 'destroy']);

// User Management Routes (Admin only)
Route::middleware(['auth:sanctum', 'role:Admin'])
    ->get('/users', [UserController::class, 'index']);

Route::middleware(['auth:sanctum', 'role:Admin'])
    ->post('/users', [UserController::class, 'store']);

Route::middleware(['auth:sanctum', 'role:Admin'])
    ->put('/users/{user}', [UserController::class, 'update']);
