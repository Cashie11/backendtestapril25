<?php

namespace App\Console\Commands;

use App\Jobs\SendWeeklyExpenseReport;
use Illuminate\Console\Command;

class TestWeeklyExpenseReport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:test-weekly-expense-report';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Test the weekly expense report job';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Dispatching SendWeeklyExpenseReport job...');
        
        SendWeeklyExpenseReport::dispatch();
        
        $this->info('Job dispatched successfully. Check the logs for details.');
        
        return Command::SUCCESS;
    }
}
