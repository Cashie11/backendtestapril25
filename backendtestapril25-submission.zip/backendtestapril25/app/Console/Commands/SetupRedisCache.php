<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Redis as RedisManager;

class SetupRedisCache extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:setup-redis-cache';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Configure the application to use Redis for caching';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Setting up Redis for caching...');
        
        // Check if Redis is installed
        $this->info('Checking if Redis is installed...');
        $redisInstalled = $this->checkRedisInstalled();
        
        if (!$redisInstalled) {
            $this->error('Redis does not appear to be installed or running.');
            $this->info('Please install Redis and make sure it is running before continuing.');
            $this->info('You can install Redis with: sudo apt-get install redis-server');
            $this->info('Then start it with: sudo systemctl start redis-server');
            return Command::FAILURE;
        }
        
        $this->info('Redis appears to be installed and running.');
        
        // Update .env file
        $this->info('Updating .env file to use Redis for caching...');
        $envPath = base_path('.env');
        
        if (File::exists($envPath)) {
            $envContent = File::get($envPath);
            
            // Update cache settings
            $envContent = preg_replace('/CACHE_STORE=.*/', 'CACHE_STORE=redis', $envContent);
            
            // Make sure Redis settings are present
            if (!preg_match('/REDIS_HOST=/', $envContent)) {
                $envContent .= "\n\nREDIS_HOST=127.0.0.1";
                $envContent .= "\nREDIS_PASSWORD=null";
                $envContent .= "\nREDIS_PORT=6379";
            }
            
            File::put($envPath, $envContent);
            $this->info('Updated .env file successfully.');
        } else {
            $this->error('.env file not found.');
            return Command::FAILURE;
        }
        
        // Clear cache
        $this->info('Clearing cache...');
        $this->call('cache:clear');
        
        $this->info('Redis cache setup complete!');
        $this->info('Your application is now configured to use Redis for caching.');
        
        return Command::SUCCESS;
    }
    
    /**
     * Check if Redis is installed and running.
     */
    private function checkRedisInstalled(): bool
    {
        try {
            // Use Laravel's Redis facade to check connection
            RedisManager::ping();
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
