<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CompanyAccessMiddleware
{
    /**
     * Ensure the authenticated user only accesses their own company's data.
     * Usage: company.access
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        $companyId = $request->route('company_id') ?? $request->input('company_id');
        // If no company_id is specified, allow (for listing, etc.)
        if ($companyId && $user && $user->company_id != $companyId) {
            return response()->json(['message' => 'Forbidden. Company data access denied.'], 403);
        }
        return $next($request);
    }
}
