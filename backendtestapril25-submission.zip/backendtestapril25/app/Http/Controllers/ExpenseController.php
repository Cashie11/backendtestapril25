<?php

namespace App\Http\Controllers;

use App\Models\Expense;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class ExpenseController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth:sanctum', 'role:Admin,Manager,Employee']);
    }

    // GET /api/expenses
    public function index(Request $request)
    {
        $user = $request->user();
        $query = Expense::with('user')
            ->where('company_id', $user->company_id);
        if ($request->has('title')) {
            $query->where('title', 'like', '%'.$request->title.'%');
        }
        if ($request->has('category')) {
            $query->where('category', $request->category);
        }
        $expenses = Cache::remember(
            'expenses_company_'.$user->company_id.'_'.md5(json_encode($request->all())),
            60,
            fn() => $query->orderByDesc('created_at')->paginate(10)
        );
        return response()->json($expenses);
    }

    // POST /api/expenses
    public function store(Request $request)
    {
        $user = $request->user();
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'category' => 'required|string|max:255',
        ]);
        $expense = Expense::create([
            'company_id' => $user->company_id,
            'user_id' => $user->id,
            'title' => $validated['title'],
            'amount' => $validated['amount'],
            'category' => $validated['category'],
        ]);
        Cache::forget('expenses_company_'.$user->company_id);
        return response()->json($expense, 201);
    }

    // PUT /api/expenses/{expense}
    public function update(Request $request, Expense $expense)
    {
        $user = $request->user();
        if (!in_array($user->role, ['Admin', 'Manager'])) {
            return response()->json(['message' => 'Forbidden'], 403);
        }
        if ($expense->company_id !== $user->company_id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }
        $old = $expense->toArray();
        $validated = $request->validate([
            'title' => 'sometimes|string|max:255',
            'amount' => 'sometimes|numeric|min:0',
            'category' => 'sometimes|string|max:255',
        ]);
        $expense->update($validated);
        AuditLog::create([
            'user_id' => $user->id,
            'company_id' => $user->company_id,
            'action' => 'update',
            'changes' => [
                'old' => $old,
                'new' => $expense->toArray(),
            ],
        ]);
        Cache::forget('expenses_company_'.$user->company_id);
        return response()->json($expense);
    }

    // DELETE /api/expenses/{expense}
    public function destroy(Request $request, Expense $expense)
    {
        $user = $request->user();
        if ($user->role !== 'Admin') {
            return response()->json(['message' => 'Forbidden'], 403);
        }
        if ($expense->company_id !== $user->company_id) {
            return response()->json(['message' => 'Forbidden'], 403);
        }
        $old = $expense->toArray();
        $expense->delete();
        AuditLog::create([
            'user_id' => $user->id,
            'company_id' => $user->company_id,
            'action' => 'delete',
            'changes' => [
                'old' => $old,
            ],
        ]);
        Cache::forget('expenses_company_'.$user->company_id);
        return response()->json(['message' => 'Deleted']);
    }
}
