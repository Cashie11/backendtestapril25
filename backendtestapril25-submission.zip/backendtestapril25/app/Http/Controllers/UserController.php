<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * UserController constructor.
     */
    public function __construct()
    {
        // The middleware will be applied via the routes instead
    }

    // GET /api/users - List users (Admins only)
    public function index(Request $request)
    {
        $user = $request->user();
        $users = User::where('company_id', $user->company_id)
            ->orderBy('name')
            ->paginate(10);
        
        return response()->json($users);
    }

    // POST /api/users - Add user (Admins only)
    public function store(Request $request)
    {
        $user = $request->user();
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
            'role' => ['required', Rule::in(['Admin', 'Manager', 'Employee'])],
        ]);

        $newUser = User::create([
            'company_id' => $user->company_id,
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'role' => $validated['role'],
        ]);

        return response()->json($newUser, 201);
    }

    // PUT /api/users/{id} - Update user role (Admins only)
    public function update(Request $request, User $user)
    {
        $currentUser = $request->user();
        
        // Ensure the user belongs to the same company
        if ($user->company_id !== $currentUser->company_id) {
            return response()->json(['message' => 'Forbidden. User not found in your company.'], 403);
        }

        $validated = $request->validate([
            'role' => ['required', Rule::in(['Admin', 'Manager', 'Employee'])],
        ]);

        $user->update([
            'role' => $validated['role'],
        ]);

        return response()->json($user);
    }
}
