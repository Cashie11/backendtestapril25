<?php

namespace App\Jobs;

use App\Models\User;
use App\Models\Expense;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class SendWeeklyExpenseReport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        // Get all companies with their admin users
        $adminUsers = User::where('role', 'Admin')->get();
        
        // Group admin users by company
        $adminsByCompany = $adminUsers->groupBy('company_id');
        
        foreach ($adminsByCompany as $companyId => $admins) {
            // Get expenses for this company from the past week
            $startDate = Carbon::now()->subWeek();
            $endDate = Carbon::now();
            
            $expenses = Expense::where('company_id', $companyId)
                ->whereBetween('created_at', [$startDate, $endDate])
                ->with('user')
                ->get();
            
            // Calculate total expenses
            $totalAmount = $expenses->sum('amount');
            
            // Group expenses by category
            $expensesByCategory = $expenses->groupBy('category');
            $categorySummary = [];
            
            foreach ($expensesByCategory as $category => $categoryExpenses) {
                $categorySummary[$category] = [
                    'count' => $categoryExpenses->count(),
                    'total' => $categoryExpenses->sum('amount')
                ];
            }
            
            // Prepare report data
            $reportData = [
                'period' => [
                    'start' => $startDate->format('Y-m-d'),
                    'end' => $endDate->format('Y-m-d'),
                ],
                'total_expenses' => $expenses->count(),
                'total_amount' => $totalAmount,
                'category_summary' => $categorySummary,
                'expenses' => $expenses
            ];
            
            // Send email to each admin of this company
            foreach ($admins as $admin) {
                // In a real application, you would use Mail::to($admin->email)->send(new ExpenseReportMail($reportData));
                // For this test, we'll just log the action
                Log::info("Sending weekly expense report to {$admin->email} for company ID: {$companyId}");
                Log::info("Report data: " . json_encode($reportData));
            }
        }
    }
}
