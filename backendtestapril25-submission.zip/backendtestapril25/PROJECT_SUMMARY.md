# Multi-Tenant SaaS-Based Expense Management API

## Project Overview

This project implements a secure, high-performance API for a Multi-Tenant SaaS-based Expense Management System, where multiple companies can manage their expenses independently.

## Implemented Features

### Multi-Tenant Support
- Companies have isolated data
- Users can only access data from their own company
- Data is properly segmented by company_id

### Authentication & Authorization
- Laravel Sanctum for API authentication
- Role-Based Access Control (RBAC) with three roles:
  - Admin: Full access to manage users and expenses
  - Manager: Can manage expenses but not users
  - Employee: Limited to viewing and creating expenses

### API Endpoints
- **Authentication**
  - `POST /api/register` - Register a new company admin
  - `POST /api/login` - Login and get access token

- **Expense Management**
  - `GET /api/expenses` - List expenses (paginated, searchable)
  - `POST /api/expenses` - Create a new expense
  - `PUT /api/expenses/{id}` - Update an expense (Managers & Admins only)
  - `DELETE /api/expenses/{id}` - Delete an expense (Admins only)

- **User Management**
  - `GET /api/users` - List users (Admins only)
  - `POST /api/users` - Add a new user (Admins only)
  - `PUT /api/users/{id}` - Update user role (Admins only)

### Performance Optimization
- Redis caching for frequently accessed queries
- Eager loading to avoid N+1 queries
- Indexes on company_id and user_id in the expenses table

### Background Job Processing
- Weekly expense report job that sends reports to all Admins
- Laravel Scheduler to run the job automatically
- Test command to manually trigger the job

### Audit Logging
- Logs for every update/delete action on expenses
- Stores old and new values for tracking changes

## Getting Started

1. Clone the repository
2. Install dependencies: `composer install`
3. Set up the database: `php artisan migrate`
4. Start the server: `php artisan serve`

For detailed API usage instructions, see the [API_DOCUMENTATION.md](API_DOCUMENTATION.md) file.

## Redis Caching Setup

To enable Redis caching for improved performance:
```bash
php artisan app:setup-redis-cache
```

## Testing Background Jobs

To test the weekly expense report job:
```bash
php artisan app:test-weekly-expense-report
```
