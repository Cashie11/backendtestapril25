# Multi-Tenant SaaS-Based Expense Management API

This document provides instructions on how to use the Expense Management API.

## Setup and Configuration

### Redis Caching (Recommended)

The application supports Redis caching for improved performance. To set up Redis caching:

1. Make sure Redis is installed and running on your system
2. Run the setup command:
```bash
php artisan app:setup-redis-cache
```

This command will automatically configure your application to use Redis for caching.

## API Endpoints

### Authentication

#### Register a New Company Admin
```
POST /api/register
```
**Headers:**
- Content-Type: application/json
- Accept: application/json

**Request Body:**
```json
{
  "company_name": "Acme Corp",
  "company_email": "admin@acmecorp.com",
  "name": "John Doe",
  "email": "john@acmecorp.com",
  "password": "password123",
  "password_confirmation": "password123"
}
```

#### Login
```
POST /api/login
```
**Headers:**
- Content-Type: application/json
- Accept: application/json

**Request Body:**
```json
{
  "email": "john@acmecorp.com",
  "password": "password123"
}
```

### Expense Management

#### List Expenses
```
GET /api/expenses
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

**Query Parameters:**
- title (optional): Filter by title
- category (optional): Filter by category

#### Create Expense
```
POST /api/expenses
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

**Request Body:**
```json
{
  "title": "Office Supplies",
  "amount": 150.75,
  "category": "Office"
}
```

#### Update Expense (Admin and Manager only)
```
PUT /api/expenses/{expense_id}
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

**Request Body:**
```json
{
  "title": "Updated Office Supplies",
  "amount": 200.50,
  "category": "Office"
}
```

#### Delete Expense (Admin only)
```
DELETE /api/expenses/{expense_id}
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

### User Management (Admin only)

#### List Users
```
GET /api/users
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

#### Add User
```
POST /api/users
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

**Request Body:**
```json
{
  "name": "Jane Smith",
  "email": "jane@acmecorp.com",
  "password": "password123",
  "password_confirmation": "password123",
  "role": "Manager"
}
```

#### Update User Role
```
PUT /api/users/{user_id}
```
**Headers:**
- Content-Type: application/json
- Accept: application/json
- Authorization: Bearer {token}

**Request Body:**
```json
{
  "role": "Employee"
}
```

## Important Notes

1. **Authentication**: All API requests (except register and login) require a valid Bearer token in the Authorization header.

2. **Multi-Tenancy**: Users can only access data from their own company. The system enforces this restriction automatically.

3. **Role-Based Access Control**:
   - **Admin**: Can manage users and expenses
   - **Manager**: Can manage expenses but not users
   - **Employee**: Can only view and create expenses

4. **Headers**: Always include the `Accept: application/json` header to ensure proper API responses.

## Testing the Background Job

The system includes a weekly expense report job that sends reports to all company admins. To test this job, run:

```bash
php artisan app:test-weekly-expense-report
```

This will dispatch the job and log the results (actual emails are not sent in the test environment).
